import React from "react";



export type DeleteType ={
    showDelete:boolean;
    setShowDelete: Function;
    id: number;
    setId: Function;
}