import React from "react";



export type AddType ={
    showAdd:boolean;
    setShowAdd: Function;
    id: number;
    setId: Function;
}